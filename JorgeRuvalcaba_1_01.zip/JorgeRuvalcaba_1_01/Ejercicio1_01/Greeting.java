 public class Greeting {
   public void greet() {
     System.out.println("hi");
   }
 }